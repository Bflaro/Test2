import java.sql.Statement;
import java.util.List;

import daos.CustomerDao;
import entities.Customer;
import entities.Database;

import java.sql.Connection;

//Braxton Flaro

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, Test2!");

        //establishes the database connection
        try (Connection con = Database.getDatabaseConnection();
        Statement statement = con.createStatement();	
        )
        {
            //SQL Connection in Databse.java
            List<Customer> customerList;

            //Customer DOA
            CustomerDao customerDao = new CustomerDao(con);
            customerList = customerDao.findAll();

            //Insert New Customer
            Customer insertedcustomer = new Customer();
            insertedcustomer.setId(4);
            insertedcustomer.setName("Dohn Joe");
            insertedcustomer.setAddress("123 Easy Street");
            insertedcustomer.setCity("Austin");
            insertedcustomer.setState("TX");
            insertedcustomer.setZip(797239);

            customerDao.insert(insertedcustomer);
            

            // update / find by id
            Customer updateCustomer = new Customer();
            updateCustomer = customerDao.findById(4);

            updateCustomer.setAddress("456 Tough Lane");
            customerDao.update(updateCustomer);


            //delete commented out for safety
                //customerDao.delete(4); 

            //Prints all Customers
            System.out.println("Customer list printed:");
            for(Customer customer: customerList)
            {
                System.out.println(customer);
            }
        }
    }
}
