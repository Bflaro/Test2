package entities;


public class Customer {
    //getters and setters for the customer table
    Integer id;
    String name;
    String address;
    String city;
    String state;
    Integer zip;

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getid()
    {
        return id;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public String getAddress()
    {
        return address;
    }
    public void setCity(String city)
    {
        this.city = city;
    }

    public String getCity()
    {
        return city;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getState()
    {
        return state;
    }


    public void setZip(Integer zip)
    {
        this.zip = zip;
    }

    public Integer getZip()
    {
        return zip;
    }

    //this override provides the console log for all the tables
    @Override
    public String toString() {
        return "id: " + id + " name: " + name +" address: " + address + " City: " + city + " state: " + state + " zip: " + zip;
    }

}
