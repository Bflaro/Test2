package daos;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import daos.CustomerDao;
import entities.Customer;

public class CustomerDao implements Dao<Customer, Integer>{
//this provides the connection to the database
    Connection con;

    public CustomerDao(Connection con)
    {
        this.con = con;
    }

//find all will pick up all entries in the customer table
     public List<Customer> findAll()
     {
        List <Customer> customers = new ArrayList<>();
        
        try(Statement statement = con.createStatement())
        {
            ResultSet res = statement.executeQuery("SELECT * FROM customer");
            while(res.next())
            {
                Customer customer = new Customer();
                customer.setId(res.getInt("id"));
                customer.setName(res.getString("name"));
                customer.setAddress(res.getString("address"));
                customer.setCity(res.getString("city"));
                customer.setState(res.getString("state"));
                customer.setZip(res.getInt("zip"));
                customers.add(customer);
            }
        }
        catch(SQLException e)
        {
            System.err.println(e.getMessage());
    
        }
            return customers;
    }

    //insert will insert one entry into the customer table
     public void insert(Customer customer)
     {
        try (Statement statement = con.createStatement())
        {
            String insert = "INSERT INTO customer VALUES(?,?,?,?,?,?)";    
            PreparedStatement ps = con.prepareStatement(insert);
            ps.setInt(1, customer.getid());
            ps.setString(2, customer.getName());
            ps.setString(3, customer.getAddress());
            ps.setString(4, customer.getCity());
            ps.setString(5, customer.getState());
            ps.setInt(6, customer.getZip());
            ps.executeUpdate();
        } catch (SQLException e) 
        {
            System.err.println(e.getMessage());
        }  
    }

    //update will update the address feild of the customer table
     public Boolean update(Customer customer)
     {
        Boolean sucsess = true;
        String update = "UPDATE customer SET address=? WHERE ID=?";

        try(PreparedStatement ps = con.prepareStatement(update);)
        {
            ps.setString(1, customer.getAddress());
            ps.setInt(2, customer.getid());
            ps.executeUpdate();
        } catch (SQLException e) 
        {
            System.err.println(e.getMessage());
            sucsess = false;
        }  
        return sucsess;
     }

     //delete will delelte what ever record holds the given id
     public Boolean delete(Integer id)
     {  
        Boolean sucsess = false;
        String delete = "DELETE FROM customer WHERE id=?";

        try(PreparedStatement ps = con.prepareStatement(delete);)
        {
            ps.setInt(1, id);
            ps.executeUpdate();
            if(ps.executeUpdate() != 0)
            {
                sucsess = true;
            }


        } catch (SQLException e) 
        {
            System.err.println(e.getMessage());
            sucsess = true;
        }  
        return sucsess;
     }
     
     //findById will use the provided id to find the match ing table record in customers
    public Customer findById(Integer id) {
        Customer customer = new Customer();
        String select = "SELECT * FROM customer WHERE id=?";

        try(PreparedStatement ps = con.prepareStatement(select);)
        {
            ps.setInt(1, id);
            ResultSet res = ps.executeQuery();

            if(res.next())
            {
                customer.setId(res.getInt("id"));
                customer.setName(res.getString("name"));
                customer.setAddress(res.getString("Address"));
                customer.setState(res.getString("State"));
                customer.setZip(res.getInt("zip"));
            }
        } catch (SQLException e) 
        {
            System.err.println(e.getMessage());
        }
        return customer;
    }
}

